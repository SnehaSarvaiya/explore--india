﻿<div class="copyrights">
	 <p>Designed By Sneha <a href="#">MP Tourism</a> </p>
</div>	
