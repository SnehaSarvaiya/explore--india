﻿



<!--- /footer-top ---->
<!---copy-right ---->
<div class="copy-right" style="background-color:#333333;">
	<div class="container" >
	
		<div class="footer-social-icons wow fadeInDown animated animated" data-wow-delay=".5s" style="visibility: visible; animation-delay: 0.5s; animation-name: fadeInDown;">
			
		</div>
		<p class="wow zoomIn animated animated" data-wow-delay=".5s" style="visibility: visible; animation-delay: 0.5s; animation-name: zoomIn;">Designed By Sneha </p>
	</div>
</div>